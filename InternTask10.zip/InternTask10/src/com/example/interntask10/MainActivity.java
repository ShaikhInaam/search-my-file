package com.example.interntask10;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

	EditText text;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		
		text=(EditText)findViewById(R.id.editText1);
		text.setHintTextColor(Color.CYAN);
		
	}

	public void phone(View v)
	{
		Toast.makeText(getApplicationContext(), "please wait while searching", 5000).show();
		Search.text=this.text.getText().toString();
		Search.from="phone";
		Intent i=new Intent(getApplicationContext(),Search.class);
		startActivity(i);
	}
	
	public void card(View v)
	{
		Toast.makeText(getApplicationContext(), "please wait while searching", 5000).show();
		Search.text=this.text.getText().toString();
		Search.from="card";
		Intent i=new Intent(getApplicationContext(),Search.class);
		startActivity(i);
	}
	
	public void both(View v)
	{
		Toast.makeText(getApplicationContext(), "please wait while searching", 5000).show();
		Search.text=this.text.getText().toString();
		Search.from="both";
		Intent i=new Intent(getApplicationContext(),Search.class);
		startActivity(i);
	}
	
}
