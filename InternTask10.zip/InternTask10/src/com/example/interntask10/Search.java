package com.example.interntask10;

import java.io.File;
import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class Search extends Activity {

	static String from;
	static String text;
	ListView lv;
	ArrayList card=new ArrayList();
	ArrayList phone=new ArrayList();
	ArrayList filtered=new ArrayList();
	ArrayList both=new ArrayList();
	EditText filt;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_search);
		
		lv=(ListView)findViewById(R.id.listView1);
		filt=(EditText)findViewById(R.id.editText1);
		
		if(from.equalsIgnoreCase("phone")){
			File f=new File("/sdcard/");
			fileSearch(f, text,phone);
			ArrayAdapter ad=new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,phone);
			lv.setAdapter(ad);
		}
		
		if(from.equalsIgnoreCase("card"))
		{
			File f=new File("/storage/sdcard1/");
			fileSearch(f, text,card);
			ArrayAdapter ad=new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,card);
			lv.setAdapter(ad);
		}
		
		if(from.equalsIgnoreCase("both"))
		{
			File f=new File("/sdcard/");
			fileSearch(f, text,both);
			File f1=new File(Environment.getExternalStorageDirectory().getAbsolutePath());
			fileSearch(f1, text,both);
			ArrayAdapter ad=new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,both);
			lv.setAdapter(ad);
		}
	
		
	}
	
	
	private void fileSearch(File dir, String query, ArrayList<File> res) {
	    if (dir.getName().toLowerCase().contains(query.toLowerCase()))
	        res.add(dir);
	    if (dir.isDirectory() && !dir.isHidden()) {
	        if (dir.list() != null) {
	            for (File item : dir.listFiles()) {
	                fileSearch(item, query, res);
	            }
	        }
	    }
	}
	
	public void filter(View v)
	{
		
		if(from.equalsIgnoreCase("phone"))
		{
			for(int i=0;i<phone.size();i++)
			{
				if(phone.get(i).toString().endsWith(filt.getText().toString()))
				{
					filtered.add(phone.get(i));
				}
			}
			
			ArrayAdapter ad=new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,filtered);
			lv.setAdapter(ad);
		}
		
		if(from.equalsIgnoreCase("card"))
		{
			for(int i=0;i<card.size();i++)
			{
				if(card.get(i).toString().endsWith(filt.getText().toString()))
				{
					filtered.add(card.get(i));
				}
			}
			
			ArrayAdapter ad=new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,filtered);
			lv.setAdapter(ad);
		}
		
		if(from.equalsIgnoreCase("both"))
		{
			for(int i=0;i<both.size();i++)
			{
				if(both.get(i).toString().endsWith(filt.getText().toString()))
				{
					filtered.add(both.get(i));
				}
			}
			
			ArrayAdapter ad=new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,filtered);
			lv.setAdapter(ad);
		}
		
	}

	
}
